﻿using Microsoft.EntityFrameworkCore;
using LibraryManagement.Data;
using LibraryManagement.Models;
using LibraryManagement.Services;
using System;

class Program
{
    static void Main(string[] args)
    {
        //var options = new DbContextOptionsBuilder<LibraryContext>()
        //    .UseSqlServer("Server=LAPTOP-BG3587VM\\MSSQLSERVER01;Database=LibraryDb;Trusted_Connection=True;TrustServerCertificate=True;")
        //    .Options;

        using var context = new LibraryContext();
        context.Database.EnsureCreated();

        var libraryService = new LibraryService(context);

        while (true)
        {
            Console.WriteLine("Library Management System");
            Console.WriteLine("1. Add Book");
            Console.WriteLine("2. View All Books");
            Console.WriteLine("3. Update Book");
            Console.WriteLine("4. Delete Book");
            Console.WriteLine("5. Add Author");
            Console.WriteLine("6. View All Authors");
            Console.WriteLine("7. Exit");
            Console.Write("Select an option: ");
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Enter book title: ");
                    var title = Console.ReadLine();

                    Console.Write("Enter author ID: ");
                    if (int.TryParse(Console.ReadLine(), out int authorId))
                    {
                        libraryService.AddBook(new Book { Title = title, IsAvailable = true, AuthorId = authorId });
                        Console.WriteLine("Book added successfully!");
                    }
                    break;

                case "2":
                    var books = libraryService.GetAllBooks();
                    Console.WriteLine("Books in the library:");
                    foreach (var book in books)
                    {
                        Console.WriteLine($"{book.Id}: {book.Title} by {book.Author?.Name} (Available: {book.IsAvailable})");
                    }
                    break;

                case "3":
                    Console.Write("Enter book ID to update: ");
                    if (int.TryParse(Console.ReadLine(), out int updateId))
                    {
                        var bookToUpdate = libraryService.GetAllBooks().FirstOrDefault(b => b.Id == updateId);
                        if (bookToUpdate != null)
                        {
                            Console.Write("Enter new title: ");
                            bookToUpdate.Title = Console.ReadLine();

                            Console.Write("Enter new author ID: ");
                            if (int.TryParse(Console.ReadLine(), out int newAuthorId))
                            {
                                bookToUpdate.AuthorId = newAuthorId;
                            }

                            libraryService.UpdateBook(bookToUpdate);
                            Console.WriteLine("Book updated successfully!");
                        }
                        else
                        {
                            Console.WriteLine("Book not found.");
                        }
                    }
                    break;

                case "4":
                    Console.Write("Enter book ID to delete: ");
                    if (int.TryParse(Console.ReadLine(), out int deleteId))
                    {
                        libraryService.DeleteBook(deleteId);
                        Console.WriteLine("Book deleted successfully!");
                    }
                    break;

                case "5":
                    Console.Write("Enter author name: ");
                    var authorName = Console.ReadLine();
                    libraryService.AddAuthor(new Author { Name = authorName });
                    Console.WriteLine("Author added successfully!");
                    break;

                case "6":
                    var authors = libraryService.GetAllAuthors();
                    Console.WriteLine("Authors in the library:");
                    foreach (var author in authors)
                    {
                        Console.WriteLine($"{author.Id}: {author.Name}");
                    }
                    break;

                case "7":
                    return;

                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }

            Console.WriteLine();
        }
    }
}
