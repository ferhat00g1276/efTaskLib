﻿using Microsoft.EntityFrameworkCore;
using LibraryManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using LibraryManagement.Data;

namespace LibraryManagement.Services
{
    public class LibraryService
    {
        private readonly LibraryContext _context;

        public LibraryService(LibraryContext context)
        {
            _context = context;
        }


        public void AddBook(Book book)
        {
            _context.Books.Add(book);
            _context.SaveChanges();
        }


        public List<Book> GetAllBooks()
        {
            return _context.Books.Include(b => b.Author).ToList();
        }

   
        public void UpdateBook(Book book)
        {
            _context.Entry(book).State = EntityState.Modified;
            _context.SaveChanges();
        }

    
        public void DeleteBook(int id)
        {
            var book = _context.Books.Find(id);
            if (book != null)
            {
                _context.Books.Remove(book);
                _context.SaveChanges();
            }
        }

 
        public void AddAuthor(Author author)
        {
            _context.Authors.Add(author);
            _context.SaveChanges();
        }


        public List<Author> GetAllAuthors()
        {
            return _context.Authors.ToList();
        }
    }
}
